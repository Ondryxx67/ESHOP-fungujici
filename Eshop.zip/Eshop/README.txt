# ViscoTech – Školní projekt

Tento projekt představuje webovou prezentaci fikčního obchodu s elektronikou **ViscoTech**. Stránka je postavená jako Single-Page Application (SPA) v jediném souboru `index.html` s využitím HTML5, moderního CSS (Flexbox, responsivní design pomocí `@media`) a JavaScriptu pro přepínání záložek a dynamickou změnu hlavičky.

## Spuštění projektu
Projekt lze spustit otevřením souboru `index.html` v libovolném moderním webovém prohlížeči, případně jeho nahraním na školní server.

---

## Checklist splněných požadavků

* **Struktura HTML5 dokumentu a sémantické prvky**
  * Hlavní hlavička dokumentu (`<header>`) s nadpisy je v `index.html` na řádcích 168–171
  * Navigační menu (`<nav>`) je v `index.html` na řádcích 173–177
  * Hlavní obsahový prvek (`<main>`) je v `index.html` na řádcích 179–295
  * Patička stránky (`<footer>`) je v `index.html` na řádcích 297–299

* **Sémantické členění obsahu**
  * Články a sekce (`<section>`, `<article>`, `<figure>`, `<figcaption>`) jsou použity napříč celým souborem `index.html` (např. sekce výhod na řádcích 192–209, produkty na řádcích 213–233, detail produktů s obrázky na řádcích 238–294)

* **Responzivní obrázky (atributy `srcset` a `sizes`)**
  * Atributy `srcset` a `sizes` pro přizpůsobení rozlišení obrázků dle zařízení jsou použity v detailu produktů v `index.html` na řádcích 244–248, 259–263, 275–279 a 290–293

* **Vložený obsah (iframe)**
  * Vložená mapa (OpenStreetMap pomocí `<iframe>`) v sekci kontakt je v `index.html` na řádcích 308–315

* **Interaktivní formulář**
  * Kontaktní formulář pro odeslání zprávy (pole pro jméno, e-mail a textová zpráva) je v `index.html` na řádcích 320–331
* **CSS Stylování a responzivita**
  * Globální styly, flexbox layouty a layout pro mobilní zařízení pomocí media query (`@media (max-width: 650px)`) jsou definovány v bloku `<style>` v `index.html` na řádcích 6–162

* **JavaScriptová funkcionalita (SPA přepínání stránek)**
  * Skript pro dynamické přepínání obsahu stránek („Domů“, „Produkty“, „Kontakt“), aktualizaci hlaviček a scrollování je umístěn v `index.html` na řádcích 303–338




Odkaz na GitHub - https://github.com/Ondryxx67/ESHOP-fungujici
Odkaz na FileZillu - https://mikuleon25.llmp.spse-net.cz/Eshop/